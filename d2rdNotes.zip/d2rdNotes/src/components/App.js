import React, { Component } from 'react';
import logo from './D2rdroid2.png';
import './App.css';
import Notes from './Notes';
import NoteForm from './NoteForm';
import { getNotes } from '../actions';
import { connect } from 'react-redux';

class App extends Component {
  componentDidMount() {
    this.props.getNotes();
  }
  render() {
    return (
      <div className="App">
        <header className="App-header">
          <img src={logo} className="App-logo" alt="logo" />
          <h1 className="App-Title">{`Proximo Notes`}</h1>
          <NoteForm />
        </header>
        {this.props.error ? <h3>Error Fetching Notes</h3> : null}
        <div className="Flex-Container">
          {this.props.gettingNotes ? (
            <img src={logo} className="App-logo" alt="logo" />
          ) : (
            <Notes d2rdNotes={this.props.d2rdNotes} />
          )}
        </div>
      </div>
    );
  }
}

const mapStateToProps = state => {
  const { notesReducer } = state;
  return {
    d2rdNotes: notesReducer.d2rdNotes,
    error: notesReducer.error,
    gettingNotes: notesReducer.gettingNotes
  };
};

export default connect(mapStateToProps, { getNotes })(App);

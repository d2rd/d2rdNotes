import React from 'react';
import ReactDOM from 'react-dom';


<ul>
  <li className="Note-row">
    <div>
      <header className="Note-header">
        <h1>Note #1 Title {this.props.title}</h1>
      </header>
      <p className="Note-item">This is the note body.</p>
    </div>
  </li>
</ul>
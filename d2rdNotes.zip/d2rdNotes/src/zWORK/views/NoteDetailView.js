import React from 'react';
import ReactDOM from 'react-dom';

class NoteDetailView extends React.Component {
  render() {
    return <h1>I'm {this.props.title}</h1>;
  }
}

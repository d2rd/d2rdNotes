

/* Container for 
- NoteListView
- NoteDetailView
- CreateNoteView
- EditNoteView
- DeleteNoteModal

class Welcome extends React.Component {
  render() {
    return <h1>I'm {this.props.title}</h1>;
  }
}

class App extends Component {
  render() {
    return (
      <div className="App">
        
      </div>
    );
  }
}

*/







